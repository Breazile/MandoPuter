"""
MandoPuter will display text in a Mandalorian font on a tiny LCD display

File   - code.py
Author - Jon Breazile

https://github.com/Breazile/MandoPuter

Font credits to ErikStormtrooper, the bitmap fonts were created from his TrueType font
http://www.erikstormtrooper.com/mandalorian.htm
"""
import time
import board
import displayio
import terminalio
import neopixel
from analogio import AnalogIn
from adafruit_display_text import label
from adafruit_bitmap_font import bitmap_font
from adafruit_st7789 import ST7789
from adafruit_st7735r import ST7735R

# define the messages we want to display, and the time (in milliseconds) each is shown
# make sure the number of items in delays[] match the number in messages[]
messages = ["FOS", "JBM", "SOS", "TRH", "MKM"]
delays   = [ 0.88,  0.54,  0.50,  0.50,  0.50] # 0.50 is 500 milliseconds, or 1/2 of a second

# set some parameters used for shapes and text
FONTSCALE = 1                # font scaling factor (one to one pixel mapping)
BACKGROUND_COLOR = 0x000000  # Black
TEXT_COLOR = 0xFF0000        # Red
#TEXT_COLOR = 0xFFFFFF       # White - you might want this if you put a red window over the display

# setup the onboard neopixel LED, we will use it later to show battery level
led = neopixel.NeoPixel(board.NEOPIXEL, 1)
led.brightness = 0.05  # dim the LED to 5%
led[0] = (255, 0, 255) # purple

# Release any resources currently in use for the displays
displayio.release_displays()

# set things up to measure the battery voltage
vbat_voltage = AnalogIn(board.VOLTAGE_MONITOR)

def get_voltage(pin):
    return (pin.value * 3.3) / 65536 * 2

# Setup communication lines to the display
spi = board.SPI()
tft_cs = board.D6
tft_dc = board.D9
lcd_rst = board.D5

"""
This section is for setting up the correct Adafruit display
Only one set of definitions should be active below (display_bus, display, and font definitions)
all other lines should be commented out. This example uses the 1.14" display
"""
# Adafruit 1.14" display
# https://www.adafruit.com/product/4383
display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs)
display = ST7789(display_bus, rotation=270, width=240, height=135, rowstart=40, colstart=53)

# Adafruit 1.44" display
# https://www.adafruit.com/product/2088
#display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs, reset=lcd_rst)
#display = ST7735R(display_bus, width=128, height=128, colstart=2, rowstart=1)

# select the font size you want to use. Make sure it is not taller than the vertical pixel size in the display
# uncomment one, and leave the others commented out
font = bitmap_font.load_font("mandalor135.bdf")  # 135 pixel tall bitmap font
#font = bitmap_font.load_font("mandalor128.bdf")  # 128 pixel tall bitmap font
#font = bitmap_font.load_font("mandalor125.bdf")  # 125 pixel tall bitmap font
#font = bitmap_font.load_font("mandalor118.bdf")  # 118 pixel tall bitmap font
#font = bitmap_font.load_font("mandalor110.bdf")  # 110 pixel tall bitmap font

# create the background
bkground = displayio.Group(max_size=10)
color_bitmap = displayio.Bitmap(display.width, display.height, 1)
color_palette = displayio.Palette(1)
color_palette[0] = BACKGROUND_COLOR
bg_sprite = displayio.TileGrid(color_bitmap,
                               pixel_shader=color_palette,
                               x=0, y=0)
bkground.append(bg_sprite)
display.show(bkground)

# font rendering function
def render_font(glyphs, disp_width, group):
    text_area = label.Label(font, text=glyphs, color=TEXT_COLOR)
    text_spacer = int((disp_width - (text_area.bounding_box[2] * FONTSCALE))/4)
    index = 0
    next_position=text_spacer
    for pos in glyphs:
        text_area = label.Label(font, text=pos, color=TEXT_COLOR)
        text_width = text_area.bounding_box[2] * FONTSCALE
        text_group = displayio.Group(max_size=10, scale=FONTSCALE, x=next_position,
                             y=display.height // 2)
        text_group.append(text_area) # Subgroup for text scaling
        group.append(text_group)
        next_position = next_position + text_width + text_spacer
        index = index + 1

# render the text in the bitmap font
splashes = []
index = 0
for msg in messages:
    splashes.append(displayio.Group(max_size=10))
    render_font(msg, display.width, splashes[index])
    index = index + 1

# loop through and display each message for the specified duration
while True:
    index = 0
    for splash in splashes:
        display.show(splash)
        time.sleep(delays[index])
        index = index + 1

    # color the onboard neopixel to show battery level
    battery_voltage = get_voltage(vbat_voltage)
    # with a full battery the color will start out green,
    # then change to yellow, orange, and then red
    # as the battery drains
    if battery_voltage > 3.75 :
        led[0] = (0, 255, 0) # green
    elif battery_voltage > 3.7 :
        led[0] = (192, 127, 0) # yellow
    elif battery_voltage > 3.65 :
        led[0] = (255, 40, 0) # orange
    else:
        led[0] = (255, 0, 0) # red