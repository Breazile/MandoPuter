"""
MandoPuter will display text in a Mandalorian font on a tiny LCD display

File   - code.py
Author - Jon Breazile

https://github.com/Breazile/MandoPuter

Font credits to Erik Schroeder, the bitmap fonts were created from his TrueType font
http://www.erikstormtrooper.com/mandalorian.htm
"""
import time
import board
import displayio
import terminalio
import neopixel
from adafruit_display_text import label
from adafruit_st7789 import ST7789
from adafruit_bitmap_font import bitmap_font

# define the messages we want to display, and the time (in milliseconds) each is shown
# make sure the number of items in delays[] match the number in messages[]
messages = ["FOS", "JBM", "SOS", "TRH", "MKM"]
delays   = [ 0.88,  0.54,  0.50,  0.50,  0.50] # 0.50 is 500 milliseconds, or 1/2 of a second

# set some parameters used for shapes and text
FONTSCALE = 1                # font scaling factor (one to one pixel mapping)
BACKGROUND_COLOR = 0x000000  # Black
TEXT_COLOR = 0xFF0000        # Red
#TEXT_COLOR = 0xFFFFFF       # White

# setup the onboard neopixel LED
led = neopixel.NeoPixel(board.NEOPIXEL, 1)
led.brightness = 0.01  # dim the LED to 1%
led[0] = (255, 0, 255) # purple = 255 red, 0 green, 255 blue

# load the bitmap font
font = bitmap_font.load_font("mandalor125.bdf")  # 125 pixel tall bitmap font

# Release any resources currently in use for the displays
displayio.release_displays()

# Setup communication lines to the display
spi = board.SPI()
tft_cs = board.D6
tft_dc = board.D9
display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs)
display = ST7789(display_bus, rotation=270, width=240, height=135, rowstart=40, colstart=53)

# create the background
bkground = displayio.Group(max_size=10)
color_bitmap = displayio.Bitmap(display.width, display.height, 1)
color_palette = displayio.Palette(1)
color_palette[0] = BACKGROUND_COLOR
bg_sprite = displayio.TileGrid(color_bitmap,
                               pixel_shader=color_palette,
                               x=0, y=0)
bkground.append(bg_sprite)
display.show(bkground)

# font rendering function
def render_font(glyphs, disp_width, group):
    text_area = label.Label(font, text=glyphs, color=TEXT_COLOR)
    text_spacer = int((disp_width - (text_area.bounding_box[2] * FONTSCALE))/5)
    index = 0
    for pos in glyphs:
        text_area = label.Label(font, text=pos, color=TEXT_COLOR)
        text_width = text_area.bounding_box[2] * FONTSCALE
        text_group = displayio.Group(max_size=10, scale=FONTSCALE, x=(index*80)+text_spacer,
                                 y=display.height // 2)
        text_group.append(text_area) # Subgroup for text scaling
        group.append(text_group)
        index = index + 1

# render the text in the bitmap font
splashes = []
index = 0
for msg in messages:
    splashes.append(displayio.Group(max_size=10))
    render_font(msg, display.width, splashes[index])
    index = index + 1

# loop through and display each message for the specified duration
while True:
    index = 0
    for splash in splashes:
        display.show(splash)
        time.sleep(delays[index])
        index = index + 1