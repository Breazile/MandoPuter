"""
This test will initialize the display using displayio and draw a solid green
background, a smaller purple rectangle, and some yellow text.
"""
import time
import board
import displayio
import terminalio
from adafruit_display_text import label
from adafruit_st7789 import ST7789
from adafruit_bitmap_font import bitmap_font

font = bitmap_font.load_font("mandalor125.bdf")

# First set some parameters used for shapes and text
BORDER = 0
FONTSCALE = 1
BACKGROUND_COLOR = 0x000000  # Bright Green
TEXT_COLOR = 0xFF0000

# Release any resources currently in use for the displays
displayio.release_displays()

spi = board.SPI()
tft_cs = board.D6
tft_dc = board.D9

display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs)
display = ST7789(display_bus, rotation=90, width=240, height=135, rowstart=40, colstart=53)

# Make the display context
splash = displayio.Group(max_size=10)
display.show(splash)

color_bitmap = displayio.Bitmap(display.width, display.height, 1)
color_palette = displayio.Palette(1)
color_palette[0] = BACKGROUND_COLOR

bg_sprite = displayio.TileGrid(color_bitmap,
                               pixel_shader=color_palette,
                               x=0, y=0)
splash.append(bg_sprite)

# Draw a label
text1 = "A B C"
text1_area = label.Label(font, text=text1, color=TEXT_COLOR)
text1_width = text1_area.bounding_box[2] * FONTSCALE
text1_group = displayio.Group(max_size=10, scale=FONTSCALE, x=display.width // 2 - text1_width // 2,
                             y=display.height // 2)
text1_group.append(text1_area) # Subgroup for text scaling

text2 = "D E F"
text2_area = label.Label(font, text=text2, color=TEXT_COLOR)
text2_width = text2_area.bounding_box[2] * FONTSCALE
text2_group = displayio.Group(max_size=10, scale=FONTSCALE, x=display.width // 2 - text2_width // 2,
                             y=display.height // 2)
text2_group.append(text2_area) # Subgroup for text scaling

splash.append(text1_group)
#time.sleep(3)
#splash.append(bg_sprite)
#splash.append(text2_group)
#time.sleep(3)
#splash.append(bg_sprite)

while True:
    pass