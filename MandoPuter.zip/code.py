"""
MandoPuter will display text in a Mandalorian font on a tiny LCD display

File   - code.py
Author - Jon Breazile

https://github.com/Breazile/MandoPuter

Font credits to ErikStormtrooper, the bitmap fonts were created from his TrueType font
http://www.erikstormtrooper.com/mandalorian.htm
"""
import time
import board
import neopixel
import displayio
import terminalio
from analogio import AnalogIn
import adafruit_dotstar as dotstar
from adafruit_display_text import label
from adafruit_bitmap_font import bitmap_font
from adafruit_st7789 import ST7789
from adafruit_st7735r import ST7735R
from adafruit_ssd1331 import SSD1331
from adafruit_ssd1351 import SSD1351
from adafruit_displayio_ssd1306 import SSD1306

# define the messages we want to display, and the time (in milliseconds) each is shown
# make sure the number of items in delays[] match the number in messages[]
messages = ["TIO", "NAS", "TRH", "FOS", "MKM"]
delays   = [ 0.50,  0.50,  0.50,  0.50,  0.50] # 0.50 is 500 milliseconds, or 1/2 of a second

# set some parameters used for shapes and text
BOARD_TYPE = "Feather"       # Feather M4 Express
#BOARD_TYPE = "ItsyBitsy"    # ItsyBitsy M4 Express
FONTSCALE = 1                # font scaling factor (one to one pixel mapping)
BACKGROUND_COLOR = 0x000000  # Black
TEXT_COLOR = 0xFF0000        # Red
#TEXT_COLOR = 0xFFFFFF       # White - you might want this if you put a red window over the display
BATTERY_80 = 3.75            # voltage for the battery at 80% capacity
BATTERY_30 = 3.53            # voltage for the battery at 30% capacity
BATTERY_15 = 3.48            # voltage for the battery at 15% capacity
BATT_SAMPLE_AVG = 50         # rolling number of battery readings to average (IIR filter)
VOLT_LOG_INVERVAL = 00       # log voltage every n seconds. Set to 0 to disable battery logging
                             # for logging to work read the comments in LogVoltage() below

# setup the onboard neopixel LED, we will use it later to show battery level
if BOARD_TYPE == "Feather" :
    led = neopixel.NeoPixel(board.NEOPIXEL, 1)  # Feather M4 Express
else :
    led = dotstar.DotStar(board.APA102_SCK, board.APA102_MOSI, 1) # ItsyBitsy M4 Express
led.brightness = 0.05  # dim the LED to 5%
led[0] = (255, 0, 255) # purple

# Release any resources currently in use for the displays
displayio.release_displays()

# set things up to measure the battery voltage
vbat_voltage = AnalogIn(board.VOLTAGE_MONITOR)

def get_voltage(pin):
    return (pin.value * 3.3) / 65536 * 2

# Setup communication lines to the display
spi = board.SPI()
if BOARD_TYPE == "Feather" :
    tft_cs = board.D6   # Feather M4 Express
    tft_dc = board.D9
    lcd_rst = board.D5
else :
    tft_cs = board.D2   # ItsyBitsy M4 Express
    tft_dc = board.D3
    lcd_rst = board.D4

"""
This section is for setting up the correct Adafruit display
Only one set of definitions should be active below (display_bus, display)
all other lines should be commented out (a comment starts with a # character)

Make sure you set the rotation value to 0, 90, 180, or 270 for the proper text orientation

This example uses the 1.14" display with a rotation of 270
"""
# Adafruit 0.96" OLED display
# https://www.adafruit.com/product/684
#display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs, reset=lcd_rst)
#display = SSD1331(display_bus, rotation=270, width=96, height=64)

# Adafruit 1.14" LCD display
# https://www.adafruit.com/product/4383
display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs)
display = ST7789(display_bus, rotation=270, width=240, height=135, rowstart=40, colstart=53)

# Adafruit 1.27" OLED display
# https://www.adafruit.com/product/1673
#display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs,
#                                 reset=lcd_rst, baudrate=16000000
#display = SSD1351(display_bus, rotation=270, width=128, height=128)

# Adafruit 1.3" LCD display
# https://www.adafruit.com/product/4313
#display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs, reset=lcd_rst)
#display = ST7789(display_bus, rotation=270, width=240, height=240, rowstart=80)

# Adafruit 1.3" Monochrome OLED display
# https://www.adafruit.com/product/938
#display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs,
#                                 reset=lcd_rst, baudrate=1000000)
#display = adafruit_displayio_ssd1306.SSD1306(display_bus, rotation=270, width=128, height=64)

# Adafruit 1.44" LCD display
# https://www.adafruit.com/product/2088
#display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs, reset=lcd_rst)
#display = ST7735R(display_bus, rotation=270, rotation=270, width=128, height=128, colstart=2, rowstart=1)

# Adafruit 1.5" OLED display
# https://www.adafruit.com/product/1431
#display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs,
#                                 reset=lcd_rst, baudrate=16000000
#display = SSD1351(display_bus, rotation=270, width=128, height=128)

# Adafruit 1.54" LCD display
# https://www.adafruit.com/product/3787
#display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs, reset=lcd_rst)
#display = ST7789(display_bus, rotation=270, width=240, height=240, rowstart=80)

# Adafruit 1.8" LCD display
# https://www.adafruit.com/product/358
#display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs, reset=lcd_rst)
#display = ST7735R(display_bus, rotation=270, width=160, height=128, rotation=90, bgr=True)

# select the font size you want to use. Make sure it is not taller than the vertical pixel size in the display
# uncomment one, and leave the others commented out
#font = bitmap_font.load_font("mandalor60.bdf")  # 60 pixel tall bitmap font
#font = bitmap_font.load_font("mandalor64.bdf")  # 64 pixel tall bitmap font
#font = bitmap_font.load_font("mandalor110.bdf")  # 110 pixel tall bitmap font
#font = bitmap_font.load_font("mandalor118.bdf")  # 118 pixel tall bitmap font
#font = bitmap_font.load_font("mandalor125.bdf")  # 125 pixel tall bitmap font
#font = bitmap_font.load_font("mandalor128.bdf")  # 128 pixel tall bitmap font
font = bitmap_font.load_font("mandalor135.bdf")  # 135 pixel tall bitmap font
#font = bitmap_font.load_font("mandalor200.bdf")  # 200 pixel tall bitmap font
#font = bitmap_font.load_font("mandalor220.bdf")  # 220 pixel tall bitmap font
#font = bitmap_font.load_font("mandalor240.bdf")  # 240 pixel tall bitmap font

# create the background
bkground = displayio.Group(max_size=10)
color_bitmap = displayio.Bitmap(display.width, display.height, 1)
color_palette = displayio.Palette(1)
color_palette[0] = BACKGROUND_COLOR
bg_sprite = displayio.TileGrid(color_bitmap,
                               pixel_shader=color_palette,
                               x=0, y=0)
bkground.append(bg_sprite)
display.show(bkground)

# font rendering function
def render_font(glyphs, disp_width, group):
    text_area = label.Label(font, text=glyphs, color=TEXT_COLOR)
    text_spacer = int((disp_width - (text_area.bounding_box[2] * FONTSCALE))/4)
    index = 0
    next_position=text_spacer
    for pos in glyphs:
        text_area = label.Label(font, text=pos, color=TEXT_COLOR)
        text_width = text_area.bounding_box[2] * FONTSCALE
        text_group = displayio.Group(max_size=10, scale=FONTSCALE, x=next_position,
                             y=display.height // 2)
        text_group.append(text_area) # Subgroup for text scaling
        group.append(text_group)
        next_position = next_position + text_width + text_spacer
        index = index + 1

# render the text in the bitmap font
splashes = []
index = 0
for msg in messages:
    splashes.append(displayio.Group(max_size=10))
    render_font(msg, display.width, splashes[index])
    index = index + 1

def wheel(pos):
    # Input a value 0 to 255 to get a color value.
    # The colours are a transition r - g - b - back to r.
    if pos < 0 or pos > 255:
        return 0, 0, 0
    if pos < 85:
        return int(255 - pos * 3), int(pos * 3), 0
    if pos < 170:
        pos -= 85
        return 0, int(255 - pos * 3), int(pos * 3)
    pos -= 170
    return int(pos * 3), 0, int(255 - (pos * 3))

def LogVoltage(voltage):
    # you'll need to have boot.py copied to the Feather
    # Connect pin D4 to GND on power on in order for this to work
    # see https://learn.adafruit.com/circuitpython-essentials/circuitpython-storage
    try:
        with open("/battvolt.txt", "a") as fp:
            fp.write('{0:f}\n'.format(voltage))
            fp.flush()
    except OSError as e:
        # Could not write to the file. Most likely because the correct boot.py
        # was not copied to the system, and the D4 pin was not grounded on power on
        delay = 0.1
        if e.args[0] == 28:
            delay = 0.01
        i = 0
        while True:
            i = (i + 1) % 256  # run from 0 to 255
            led.fill(wheel(i))
            time.sleep(delay)

# read and average the battery voltage
def GetAvgBattVoltage(voltage) :
    voltage = (get_voltage(vbat_voltage) * (1 / BATT_SAMPLE_AVG)) + (voltage * (1 - (1 / BATT_SAMPLE_AVG)))
    return voltage

# loop through and display each message for the specified duration
next_log = time.time() + VOLT_LOG_INVERVAL
avg_voltage = get_voltage(vbat_voltage)

while True:
    index = 0
    for splash in splashes:
        avg_voltage = GetAvgBattVoltage(avg_voltage)
        display.show(splash)
        avg_voltage = GetAvgBattVoltage(avg_voltage)
        time.sleep(delays[index])
        avg_voltage = GetAvgBattVoltage(avg_voltage)
        index = index + 1

     # log the battery voltage to a file (if enabled)
    if VOLT_LOG_INVERVAL > 0 :
        if time.time() > next_log :
            print(avg_voltage)
            #LogVoltage(avg_voltage)
            next_log = time.time() + VOLT_LOG_INVERVAL

    # color the onboard neopixel to show battery level
    if avg_voltage > BATTERY_80 :
        led[0] = (0, 255, 0) # green    - 100% to 81% capacity
    elif avg_voltage > BATTERY_30 :
        led[0] = (192, 127, 0) # yellow - 80%  to 31% capacity
    elif avg_voltage > BATTERY_15 :
        led[0] = (255, 46, 0) # orange  - 30%  to 16% capacity
    else:
        led[0] = (255, 0, 0) # red      - 15%  to  0% capacity